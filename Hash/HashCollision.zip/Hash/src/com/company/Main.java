package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Hash[] h = new Hash[9];

        h[0] = new Hash();
        h[1] = new Hash();
        h[2] = new Hash();
        h[3] = new Hash();
        h[4] = new Hash();



        h[0].key = 0;

        h[1].key = 1;
        h[2].key = 2;
        h[3].key = 3;
        h[4].key = 4;

        h[0].value = 12;
        h[1].value = 13;
        h[2].value = 18;
        h[3].value = 26;
        h[4].value = 14;

        Scanner s = new Scanner(System.in);
        int key = s.nextInt();

        System.out.println(h[key % 5].value);
    }
}
