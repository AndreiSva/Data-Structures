package com.company;

public class Hash {

    public int value;
    public int key;

//    public Hash(int value, int key){
//
//        this.value = value;
//        this.key = key;
//    }
}
