package com.company;

public class HashMap {
}
