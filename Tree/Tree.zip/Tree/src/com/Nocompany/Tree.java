package com.Nocompany;

public class Tree
{
    int value;

    public Tree Left;
    public Tree Right;

    public Tree(int value){
        this.value = value;
        Left = null;
        Right = null;
    }
}
