package com.Nocompany;

public class TreeFunc
{

}
