package com.company;

public class InsertionSort{
    public int[] Insert(int[] array)
        {
            for (int i=0; i < array.length; i++)
            {
                for (int j=1; j > 0; j--)
                if(array[j] < array[j-1]){

            }
            }
        }
}
